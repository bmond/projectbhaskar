webinarApp.config(function($stateProvider,$urlRouterProvider)
{
	$stateProvider.state('reports',
	{
		url: '/chat',
		controller:'homeController',
		templateUrl :'templates/home.html'
	});
	
});






	

	
