var webinarApp = angular.module("webinarApp",['ui.router','chart.js']);


