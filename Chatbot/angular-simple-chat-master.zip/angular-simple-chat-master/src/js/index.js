angular
    .module('angular-simple-chat', [
        'angular-simple-chat.directives'
    ]);

angular
    .module('angular-simple-chat.directives', []);
