<a name="1.0.11"></a>
## 1.0.11 (2017-01-23)

* use use ng-attr-placeholder

<a name="1.0.10"></a>
## 1.0.10 (2016-03-02)

### Bug fix

* userName instead of username

<a name="1.0.9"></a>
## 1.0.9 (2016-03-02)

### Bug fix

* userName instead of username

<a name="1.0.8"></a>
## 1.0.8 (2016-02-26)

### Bug fix

* userName instead of username

<a name="1.0.7"></a>
## 1.0.7 (2016-02-28)

### Features

* live flags added (startSentence, endSentence)

<a name="1.0.6"></a>
## 1.0.6 (2016-02-26)

### Bug fix

* bubble multiline support

<a name="1.0.5"></a>
## 1.0.5 (2016-02-26)

### Features

* **show-bubble-infos:** show/hide bubble infos

<a name="1.0.4"></a>
## 1.0.4 (2016-02-24)

### Features

* **live:** activate live mode

### Technical

* messages management inside angular-simple-chat directive, not in parent's controller

<a name="1.0.3"></a>
## 1.0.3 (2016-02-18)

### Bug fix

* isolate configuration override

### Technical

* cleaning configuration sharing between directives

<a name="1.0.2"></a>
## 1.0.2 (2016-02-13)

### Bug fix

* isolate configuration for two directives on same page

<a name="1.0.1"></a>
## 1.0.1 (2016-02-13)

### Features

* **show-composer:** option to show/hide the composer
* if started with archived messages, scroll down the list

### Breaking change

* due to angular-moment issue in AMD with theintern.io, the amTimeAgo directive is copied internally waiting fix.

<a name"1.0.0"></a>
## 1.0.0 (2016-02-11)

Initial release
