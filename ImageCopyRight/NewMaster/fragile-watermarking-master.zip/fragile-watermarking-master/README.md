#Fragile Watermarking Implementation for IF4020 Crypthograpy Assignment

## Assignment Specification
http://informatika.stei.itb.ac.id/~rinaldi.munir/Kriptografi/2016-2017/Tubes1-Kripto-2016.doc

## Reference
A Chaos-based Fragile Watermarking Method in Spatial Domain for Image Authentication
http://informatika.stei.itb.ac.id/~rinaldi.munir/Kriptografi/2016-2017/Makalah_ISITIA_2015.pdf